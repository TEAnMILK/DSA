package phonebook;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

class Contact {
    String name;
    String phoneNumber;

    Contact(String name, String phoneNumber) {
        this.name = name;
        this.phoneNumber = phoneNumber;
    }
}

public class Phonebook {
    static ArrayList<Contact> phonebook = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Phonebook Menu:");
            System.out.println("1. Insert Contact");
            System.out.println("2. Search Contact");
            System.out.println("3. Display All Contacts");
            System.out.println("4. Delete Contact");
            System.out.println("5. Update Contact");
            System.out.println("6. Sort Contacts");
            System.out.println("7. Analyze Search Efficiency");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phoneNumber = scanner.nextLine();
                    insertContact(name, phoneNumber);
                    break;
                case 2:
                    System.out.print("Enter name to search: ");
                    name = scanner.nextLine();
                    Contact result = searchContact(name);
                    if (result != null) {
                        System.out.println("Contact found: Name = " + result.name + ", Phone Number = " + result.phoneNumber);
                    } else {
                        System.out.println("Contact not found");
                    }
                    break;
                case 3:
                    displayAllContacts();
                    break;
                case 4:
                    System.out.print("Enter name to delete: ");
                    name = scanner.nextLine();
                    deleteContact(name);
                    break;
                case 5:
                    System.out.print("Enter name to update: ");
                    name = scanner.nextLine();
                    System.out.print("Enter new phone number: ");
                    String newPhoneNumber = scanner.nextLine();
                    updateContact(name, newPhoneNumber);
                    break;
                case 6:
                    sortContacts();
                    break;
                case 7:
                    analyzeSearchEfficiency();
                    break;
                case 8:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }

    static void insertContact(String name, String phoneNumber) {
        Contact newContact = new Contact(name, phoneNumber);
        phonebook.add(newContact);
        System.out.println("Contact added: " + name);
    }

    static Contact searchContact(String name) {
        for (Contact contact : phonebook) {
            if (contact.name.equalsIgnoreCase(name)) {
                return contact;
            }
        }
        return null;
    }

    static void displayAllContacts() {
        if (phonebook.isEmpty()) {
            System.out.println("Phonebook is empty.");
        } else {
            for (Contact contact : phonebook) {
                System.out.println("Name: " + contact.name + ", Phone Number: " + contact.phoneNumber);
            }
        }
    }

    static void deleteContact(String name) {
        Contact contactToRemove = searchContact(name);
        if (contactToRemove != null) {
            phonebook.remove(contactToRemove);
            System.out.println("Contact deleted: " + name);
        } else {
            System.out.println("Contact not found.");
        }
    }

    static void updateContact(String name, String newPhoneNumber) {
        Contact contactToUpdate = searchContact(name);
        if (contactToUpdate != null) {
            contactToUpdate.phoneNumber = newPhoneNumber;
            System.out.println("Contact updated: " + name);
        } else {
            System.out.println("Contact not found.");
        }
    }

    static void sortContacts() {
        Collections.sort(phonebook, new Comparator<Contact>() {
            public int compare(Contact c1, Contact c2) {
                return c1.name.compareToIgnoreCase(c2.name);
            }
        });
        System.out.println("Contacts sorted.");
    }

    static void analyzeSearchEfficiency() {
        System.out.println("Search Time Complexity: O(n)");
    }
}

